#include "Library.h"

#include <fstream>

#include "Exceptions.h"
#include "TextUtil.h"

void Library::addBook(const Book& book) {
    if (books_.count(book.getId()) > 0) throw DuplicateBook(book.getId());
    books_.emplace(book.getId(), book);
}

Book& Library::find(int id) {
    auto it = books_.find(id);
    if (it == books_.end()) throw BookNotFound(id);
    return it->second;
}

const Book& Library::findById(int id) const {
    auto it = books_.find(id);
    if (it == books_.end()) throw BookNotFound(id);
    return it->second;
}

void Library::issueBook(int id) { find(id).issue(); }

void Library::returnBook(int id) { find(id).giveBack(); }

std::vector<Book> Library::search(const std::string& keyword) const {
    const std::string key = textutil::toLower(textutil::trim(keyword));
    if (key.empty()) throw InvalidInput("Search keyword cannot be empty.");

    std::vector<Book> matches;
    for (const auto& entry : books_) {
        const Book& book = entry.second;
        if (textutil::toLower(book.getTitle()).find(key) != std::string::npos ||
            textutil::toLower(book.getAuthor()).find(key) != std::string::npos) {
            matches.push_back(book);
        }
    }
    return matches;
}

std::vector<Book> Library::allBooks() const {
    std::vector<Book> result;
    result.reserve(books_.size());
    for (const auto& entry : books_) result.push_back(entry.second);
    return result;
}

void Library::saveToFile(const std::string& path) const {
    std::ofstream out(path);
    if (!out) throw FileError("Cannot open '" + path + "' for writing.");
    out << "id,title,author,available\n";
    for (const auto& entry : books_) out << entry.second.toCsvRow() << "\n";
    out.flush();
    if (!out) throw FileError("Writing to '" + path + "' failed.");
}

LoadResult Library::loadFromFile(const std::string& path) {
    std::ifstream in(path);
    if (!in) throw FileError("Cannot open '" + path + "' for reading.");

    LoadResult result;
    std::map<int, Book> loaded;  // filled first, so a failure never leaves the library half-loaded
    std::string line;
    int lineNumber = 0;

    while (std::getline(in, line)) {
        ++lineNumber;
        const std::string text = textutil::trim(line);
        if (text.empty()) continue;
        if (lineNumber == 1 && textutil::toLower(text).rfind("id,", 0) == 0) continue;  // header row

        auto skip = [&](const std::string& reason) {
            ++result.skipped;
            result.warnings.push_back("Line " + std::to_string(lineNumber) + " skipped: " + reason);
        };

        const std::vector<std::string> fields = textutil::csvSplit(text);
        if (fields.size() != 4) {
            skip("expected 4 fields but found " + std::to_string(fields.size()));
            continue;
        }
        int id = 0;
        if (!textutil::parsePositiveInt(textutil::trim(fields[0]), id)) {
            skip("invalid book ID '" + fields[0] + "'");
            continue;
        }
        const std::string flag = textutil::trim(fields[3]);
        if (flag != "0" && flag != "1") {
            skip("availability must be 0 or 1");
            continue;
        }
        if (loaded.count(id) > 0) {
            skip("duplicate book ID " + std::to_string(id));
            continue;
        }
        try {
            loaded.emplace(id, Book(id, fields[1], fields[2], flag == "1"));
            ++result.loaded;
        } catch (const LibraryError& error) {
            skip(error.what());
        }
    }
    if (in.bad()) throw FileError("Error while reading '" + path + "'.");

    books_.swap(loaded);
    return result;
}
