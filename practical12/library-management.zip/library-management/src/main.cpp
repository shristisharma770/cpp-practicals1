// main.cpp - console interface (menu) and a scripted demo for the Library Management System.
//
// Usage:
//   ./library              menu mode, data file "books.csv" in the current folder
//   ./library data/books.csv   menu mode with a chosen data file
//   ./library demo         runs the scripted demo (normal cases + error cases)
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include "Book.h"
#include "Exceptions.h"
#include "Library.h"
#include "TextUtil.h"

using namespace std;

namespace {

// Thrown when standard input ends (Ctrl+D / Ctrl+Z), so the menu can stop cleanly.
struct InputClosed {};

string readLine(const string& prompt) {
    cout << prompt << flush;
    string text;
    if (!getline(cin, text)) throw InputClosed{};
    return textutil::trim(text);
}

// Keeps asking until the user types a positive whole number.
int readPositiveInt(const string& prompt) {
    for (;;) {
        int value = 0;
        if (textutil::parsePositiveInt(readLine(prompt), value)) return value;
        cout << "  [Error] Please enter a positive whole number.\n";
    }
}

string shorten(const string& text, size_t width) {
    if (text.size() <= width) return text;
    return text.substr(0, width - 3) + "...";
}

void printBooks(const vector<Book>& books) {
    if (books.empty()) {
        cout << "  (no books to show)\n";
        return;
    }
    cout << "  " << left << setw(5) << "ID" << setw(36) << "Title" << setw(24) << "Author"
         << "Status\n";
    cout << "  " << string(74, '-') << "\n";
    for (const Book& book : books) {
        cout << "  " << left << setw(5) << book.getId() << setw(36) << shorten(book.getTitle(), 34)
             << setw(24) << shorten(book.getAuthor(), 22)
             << (book.isAvailable() ? "Available" : "Issued") << "\n";
    }
}

void printWarnings(const LoadResult& result) {
    for (const string& warning : result.warnings) cout << "    [Warning] " << warning << "\n";
}

// ---------------------------------------------------------------- demo
// Runs one action and prints either "[OK] message" or "[Error] message".
template <typename Action>
void attempt(const string& label, Action action) {
    cout << "  > " << label << "\n";
    try {
        const string message = action();  // run first: if it throws, nothing is printed as [OK]
        cout << "    [OK] " << message << "\n";
    } catch (const LibraryError& error) {
        cout << "    [Error] " << error.what() << "\n";
    }
}

void runDemo() {
    const string csvFile = "demo_books.csv";
    Library library;
    cout << "=== Library Management System - Demo ===\n";

    cout << "\n--- 1. Add books (normal cases) ---\n";
    struct Seed {
        int id;
        const char* title;
        const char* author;
    };
    const Seed seeds[] = {
        {101, "Clean Code", "Robert C. Martin"},
        {102, "The C++ Programming Language", "Bjarne Stroustrup"},
        {103, "Effective Modern C++", "Scott Meyers"},
        {104, "Introduction to Algorithms", "Thomas H. Cormen"},
        {105, "Wings of Fire", "A. P. J. Abdul Kalam"},
        {106, "Computer Networks, 5th Edition", "Andrew S. Tanenbaum"},
    };
    for (const Seed& seed : seeds) {
        attempt("Add book " + to_string(seed.id), [&] {
            library.addBook(Book(seed.id, seed.title, seed.author));
            return string("Added \"") + seed.title + "\" by " + seed.author;
        });
    }

    cout << "\n--- 2. List all books ---\n";
    printBooks(library.allBooks());

    cout << "\n--- 3. Search (case-insensitive, title or author) ---\n";
    cout << "  > Search for \"c++\"\n";
    printBooks(library.search("c++"));
    cout << "  > Search for \"KALAM\"\n";
    printBooks(library.search("KALAM"));
    cout << "  > Search for \"zzz\" (no match)\n";
    printBooks(library.search("zzz"));

    cout << "\n--- 4. Issue and return (normal cases) ---\n";
    attempt("Issue book 101", [&] {
        library.issueBook(101);
        return "Issued \"" + library.findById(101).getTitle() + "\"";
    });
    attempt("Issue book 103", [&] {
        library.issueBook(103);
        return "Issued \"" + library.findById(103).getTitle() + "\"";
    });
    cout << "  Status after issuing:\n";
    printBooks(library.allBooks());
    attempt("Return book 101", [&] {
        library.returnBook(101);
        return "Returned \"" + library.findById(101).getTitle() + "\"";
    });

    cout << "\n--- 5. Error cases (handled with exceptions) ---\n";
    attempt("Issue book 103 again (already issued)", [&] {
        library.issueBook(103);
        return string("Issued");
    });
    attempt("Issue book 999 (unknown ID)", [&] {
        library.issueBook(999);
        return string("Issued");
    });
    attempt("Return book 101 (not issued)", [&] {
        library.returnBook(101);
        return string("Returned");
    });
    attempt("Add book 102 again (duplicate ID)", [&] {
        library.addBook(Book(102, "Another Title", "Another Author"));
        return string("Added");
    });
    attempt("Add a book with an empty title", [&] {
        library.addBook(Book(110, "   ", "Some Author"));
        return string("Added");
    });
    attempt("Add a book with ID 0", [&] {
        library.addBook(Book(0, "Zero Book", "Some Author"));
        return string("Added");
    });
    attempt("Search with an empty keyword", [&] {
        library.search("  ");
        return string("Searched");
    });

    cout << "\n--- 6. Save and reload (file I/O) ---\n";
    attempt("Save the library to " + csvFile, [&] {
        library.saveToFile(csvFile);
        return "Saved " + to_string(library.size()) + " books";
    });
    Library reloaded;
    LoadResult loadResult;
    attempt("Load " + csvFile + " into a new, empty Library", [&] {
        loadResult = reloaded.loadFromFile(csvFile);
        return "Loaded " + to_string(loadResult.loaded) + " books, skipped " +
               to_string(loadResult.skipped);
    });
    printBooks(reloaded.allBooks());
    cout << "  (book 103 is still Issued, and the comma in book 106's title survived)\n";

    cout << "\n--- 7. File error cases ---\n";
    attempt("Load a file that does not exist", [&] {
        reloaded.loadFromFile("no_such_file.csv");
        return string("Loaded");
    });
    {
        ofstream bad("demo_bad.csv");
        bad << "id,title,author,available\n"
            << "201,Valid Book One,Author A,1\n"
            << "abc,Bad ID,Author B,1\n"
            << "202,Missing Fields,Author C\n"
            << "203,Valid Book Two,Author D,0\n"
            << "201,Duplicate ID,Author E,1\n";
    }
    Library tolerant;
    LoadResult badResult;
    attempt("Load demo_bad.csv (contains malformed rows)", [&] {
        badResult = tolerant.loadFromFile("demo_bad.csv");
        return "Loaded " + to_string(badResult.loaded) + " good rows, skipped " +
               to_string(badResult.skipped) + " bad rows";
    });
    printWarnings(badResult);

    cout << "\n=== Demo finished ===\n";
}

// ---------------------------------------------------------------- menu
void printMenu() {
    cout << "\n====== Library Management System ======\n"
         << " 1. List all books\n"
         << " 2. Search books (title or author)\n"
         << " 3. Add a book\n"
         << " 4. Issue a book\n"
         << " 5. Return a book\n"
         << " 6. Save now\n"
         << " 7. Run demo (normal and error cases)\n"
         << " 0. Save and exit\n";
}

void runMenu(Library& library, const string& path) {
    for (;;) {
        printMenu();
        const string choice = readLine("Enter choice: ");
        try {
            if (choice == "1") {
                printBooks(library.allBooks());
            } else if (choice == "2") {
                const string keyword = readLine("  Search for: ");
                printBooks(library.search(keyword));
            } else if (choice == "3") {
                const int id = readPositiveInt("  Book ID: ");
                const string title = readLine("  Title: ");
                const string author = readLine("  Author: ");
                library.addBook(Book(id, title, author));
                cout << "  [OK] Book added.\n";
            } else if (choice == "4") {
                const int id = readPositiveInt("  Book ID to issue: ");
                library.issueBook(id);
                cout << "  [OK] Issued \"" << library.findById(id).getTitle() << "\".\n";
            } else if (choice == "5") {
                const int id = readPositiveInt("  Book ID to return: ");
                library.returnBook(id);
                cout << "  [OK] Returned \"" << library.findById(id).getTitle() << "\".\n";
            } else if (choice == "6") {
                library.saveToFile(path);
                cout << "  [OK] Saved " << library.size() << " books to " << path << ".\n";
            } else if (choice == "7") {
                runDemo();
            } else if (choice == "0") {
                return;
            } else {
                cout << "  [Error] Please choose a number from the menu.\n";
            }
        } catch (const LibraryError& error) {
            cout << "  [Error] " << error.what() << "\n";
        }
    }
}

}  // namespace

int main(int argc, char* argv[]) {
    if (argc > 1 && string(argv[1]) == "demo") {
        runDemo();
        return 0;
    }

    const string path = (argc > 1) ? argv[1] : "books.csv";
    Library library;

    try {
        const LoadResult result = library.loadFromFile(path);
        cout << "Loaded " << result.loaded << " books from " << path;
        if (result.skipped > 0) cout << " (" << result.skipped << " bad rows skipped)";
        cout << ".\n";
        printWarnings(result);
    } catch (const FileError& error) {
        cout << error.what() << "\nStarting with an empty library.\n";
    }

    try {
        runMenu(library, path);
    } catch (const InputClosed&) {
        cout << "\nInput closed.\n";
    }

    try {
        library.saveToFile(path);
        cout << "Saved " << library.size() << " books to " << path << ". Goodbye!\n";
    } catch (const FileError& error) {
        cout << "[Error] " << error.what() << "\n";
        return 1;
    }
    return 0;
}
