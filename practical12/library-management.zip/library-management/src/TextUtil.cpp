#include "TextUtil.h"

#include <algorithm>
#include <cctype>

namespace textutil {

std::string trim(const std::string& text) {
    const char* whitespace = " \t\r\n";
    std::size_t start = text.find_first_not_of(whitespace);
    if (start == std::string::npos) return "";
    std::size_t end = text.find_last_not_of(whitespace);
    return text.substr(start, end - start + 1);
}

std::string toLower(const std::string& text) {
    std::string result = text;
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return result;
}

bool parsePositiveInt(const std::string& text, int& out) {
    if (text.empty() || text.size() > 9) return false;  // 9 digits always fit in an int
    for (char c : text) {
        if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    }
    out = std::stoi(text);
    return out > 0;
}

std::string csvEscape(const std::string& field) {
    if (field.find_first_of(",\"\n") == std::string::npos) return field;
    std::string escaped = "\"";
    for (char c : field) {
        if (c == '"') escaped += '"';  // a quote inside a quoted field is doubled
        escaped += c;
    }
    escaped += '"';
    return escaped;
}

std::vector<std::string> csvSplit(const std::string& line) {
    std::vector<std::string> fields;
    std::string current;
    bool inQuotes = false;
    for (std::size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < line.size() && line[i + 1] == '"') {
                    current += '"';  // doubled quote -> one quote character
                    ++i;
                } else {
                    inQuotes = false;
                }
            } else {
                current += c;
            }
        } else if (c == '"') {
            inQuotes = true;
        } else if (c == ',') {
            fields.push_back(current);
            current.clear();
        } else {
            current += c;
        }
    }
    fields.push_back(current);
    return fields;
}

}  // namespace textutil
