// TextUtil.h - small helper functions for text handling and CSV fields.
#pragma once
#include <string>
#include <vector>

namespace textutil {

std::string trim(const std::string& text);                 // remove leading/trailing whitespace
std::string toLower(const std::string& text);              // lower-case copy (for case-insensitive search)
bool parsePositiveInt(const std::string& text, int& out);  // true only for whole numbers > 0
std::string csvEscape(const std::string& field);           // quote a field if it has a comma or quote
std::vector<std::string> csvSplit(const std::string& line);// split one CSV line, honouring quotes

}  // namespace textutil
