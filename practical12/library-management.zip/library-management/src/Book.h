// Book.h - one book record. Data is private (encapsulation); the constructor validates it.
#pragma once
#include <string>

class Book {
public:
    // Throws InvalidInput if the ID is not positive or the title/author is empty.
    Book(int id, std::string title, std::string author, bool available = true);

    int getId() const { return id_; }
    const std::string& getTitle() const { return title_; }
    const std::string& getAuthor() const { return author_; }
    bool isAvailable() const { return available_; }

    void issue();     // throws BookUnavailable if already issued
    void giveBack();  // throws BookNotIssued if it is not issued

    std::string toCsvRow() const;  // "id,title,author,available"

private:
    int id_;
    std::string title_;
    std::string author_;
    bool available_;
};
