// Library.h - manages all books. Uses std::map (ordered by book ID) for in-memory storage.
#pragma once
#include <cstddef>
#include <map>
#include <string>
#include <vector>

#include "Book.h"

// Summary of reading a CSV file: how many rows were loaded or skipped, and why.
struct LoadResult {
    int loaded = 0;
    int skipped = 0;
    std::vector<std::string> warnings;
};

class Library {
public:
    void addBook(const Book& book);                      // throws DuplicateBook
    void issueBook(int id);                              // throws BookNotFound, BookUnavailable
    void returnBook(int id);                             // throws BookNotFound, BookNotIssued
    const Book& findById(int id) const;                  // throws BookNotFound
    std::vector<Book> search(const std::string& keyword) const;  // title or author, any case
    std::vector<Book> allBooks() const;                  // sorted by ID
    std::size_t size() const { return books_.size(); }

    void saveToFile(const std::string& path) const;      // throws FileError
    LoadResult loadFromFile(const std::string& path);    // throws FileError; skips bad rows

private:
    Book& find(int id);
    std::map<int, Book> books_;  // key = book ID
};
