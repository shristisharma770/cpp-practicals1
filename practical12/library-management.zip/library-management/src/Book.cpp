#include "Book.h"

#include "Exceptions.h"
#include "TextUtil.h"

Book::Book(int id, std::string title, std::string author, bool available)
    : id_(id),
      title_(textutil::trim(title)),
      author_(textutil::trim(author)),
      available_(available) {
    if (id_ <= 0) throw InvalidInput("Book ID must be a positive whole number.");
    if (title_.empty()) throw InvalidInput("Title cannot be empty.");
    if (author_.empty()) throw InvalidInput("Author cannot be empty.");
}

void Book::issue() {
    if (!available_) throw BookUnavailable(id_, title_);
    available_ = false;
}

void Book::giveBack() {
    if (available_) throw BookNotIssued(id_, title_);
    available_ = true;
}

std::string Book::toCsvRow() const {
    return std::to_string(id_) + "," + textutil::csvEscape(title_) + "," +
           textutil::csvEscape(author_) + "," + (available_ ? "1" : "0");
}
