// Exceptions.h - custom exception hierarchy for the Library Management System.
// Every library-specific error derives from LibraryError, which derives from std::runtime_error.
// This lets callers catch one specific error, or all library errors with a single catch.
#pragma once
#include <stdexcept>
#include <string>

class LibraryError : public std::runtime_error {
public:
    explicit LibraryError(const std::string& message) : std::runtime_error(message) {}
};

// Thrown when user input or a record fails validation (empty title, ID <= 0, ...).
class InvalidInput : public LibraryError {
public:
    explicit InvalidInput(const std::string& reason) : LibraryError("Invalid input: " + reason) {}
};

// Thrown when a book ID does not exist in the library.
class BookNotFound : public LibraryError {
public:
    explicit BookNotFound(int id)
        : LibraryError("No book found with ID " + std::to_string(id) + ".") {}
};

// Thrown when adding a book whose ID is already used.
class DuplicateBook : public LibraryError {
public:
    explicit DuplicateBook(int id)
        : LibraryError("A book with ID " + std::to_string(id) + " already exists.") {}
};

// Thrown when issuing a book that is already issued.
class BookUnavailable : public LibraryError {
public:
    BookUnavailable(int id, const std::string& title)
        : LibraryError("Book " + std::to_string(id) + " (\"" + title + "\") is already issued.") {}
};

// Thrown when returning a book that is not currently issued.
class BookNotIssued : public LibraryError {
public:
    BookNotIssued(int id, const std::string& title)
        : LibraryError("Book " + std::to_string(id) + " (\"" + title +
                       "\") is not issued, so it cannot be returned.") {}
};

// Thrown when a file cannot be opened, read or written.
class FileError : public LibraryError {
public:
    explicit FileError(const std::string& reason) : LibraryError("File error: " + reason) {}
};
