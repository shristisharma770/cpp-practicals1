# Library Management System (C++)

A console-based application written in C++17 for a small library. It stores books, lets staff search them,
issue and return them, and keeps the data in a CSV file between runs.

**Users:** a librarian or library assistant.
**Problem solved:** keeping track of which books exist and which ones are currently issued, without paper registers.

## Features
- Add a book (ID, title, author) with input validation
- List all books with their status (Available / Issued)
- Search by title or author (case-insensitive, partial match)
- Issue a book and return a book
- Save to and load from a CSV file (data is reloaded when the program starts)
- Clear error handling: unknown IDs, duplicate IDs, issuing an issued book, returning a book that is not
  issued, empty fields, missing or damaged data files
- A built-in demo (`demo` mode or menu option 7) that shows normal and error cases with realistic sample data

## Concepts used
| Concept | Where |
|---|---|
| Classes, encapsulation, constructors | `Book` (private data, validating constructor), `Library` |
| Inheritance and polymorphism | Exception hierarchy: `LibraryError` derives from `std::runtime_error`; six error classes derive from `LibraryError` and are caught through their base class / `what()` |
| STL containers and algorithms | `std::map<int, Book>` (records), `std::vector` (results), `std::transform`, `std::string` |
| Exception handling | `src/Exceptions.h`; thrown by `Book` and `Library`, caught in `main.cpp` |
| File I/O | `Library::saveToFile` / `loadFromFile` with `std::ifstream` / `std::ofstream`; bad rows are skipped with a warning |
| Git | Step-by-step commit history (see the repository history) |

## Project structure
```
library-management/
├── src/
│   ├── Exceptions.h     custom exception classes
│   ├── TextUtil.h/.cpp  trim, lower-case, number parsing, CSV helpers
│   ├── Book.h/.cpp      one book record
│   ├── Library.h/.cpp   collection of books, issue/return, save/load
│   └── main.cpp         menu, input validation and demo
├── data/books.csv       sample data (8 books, 2 issued)
├── docs/
│   ├── uml_class_diagram.png
│   └── sample_output.txt   output of the demo
├── Makefile
└── README.md
```

## Build and run
You need a C++17 compiler (g++ or clang++).

```bash
# Option 1: make
make
./library data/books.csv

# Option 2: compile directly
g++ -std=c++17 -Wall -Wextra -pedantic src/main.cpp src/Book.cpp src/Library.cpp src/TextUtil.cpp -o library
./library data/books.csv
```
On Windows (PowerShell) run `.\library.exe data/books.csv`.

| Command | What it does |
|---|---|
| `./library` | Menu mode; data file is `books.csv` in the current folder (created on first save) |
| `./library data/books.csv` | Menu mode with the sample data |
| `./library demo` | Runs the scripted demo, writes `demo_books.csv` and `demo_bad.csv` |

The program saves automatically when you choose `0` (Save and exit).
Note: running menu mode on `data/books.csv` and issuing books updates that file.

## Menu
```
====== Library Management System ======
 1. List all books
 2. Search books (title or author)
 3. Add a book
 4. Issue a book
 5. Return a book
 6. Save now
 7. Run demo (normal and error cases)
 0. Save and exit
```

## CSV format
One book per line, with a header row. Fields are `id,title,author,available` where `available` is `1`
(on the shelf) or `0` (issued). A field that contains a comma is wrapped in double quotes.
```
id,title,author,available
103,Effective Modern C++,Scott Meyers,0
108,"Computer Networks, 5th Edition",Andrew S. Tanenbaum,1
```
When loading, a row is skipped (with a warning) if it has the wrong number of fields, a bad ID, a bad
availability flag, an empty title/author, or a duplicate ID. A missing file is reported and the program
starts with an empty library.

## UML class diagram
![UML class diagram](docs/uml_class_diagram.png)

The same diagram in Mermaid (GitHub renders it):

```mermaid
classDiagram
    class Book {
        -int id_
        -string title_
        -string author_
        -bool available_
        +Book(int id, string title, string author, bool available)
        +getId() int
        +getTitle() string
        +getAuthor() string
        +isAvailable() bool
        +issue()
        +giveBack()
        +toCsvRow() string
    }
    class Library {
        -map~int, Book~ books_
        +addBook(Book book)
        +issueBook(int id)
        +returnBook(int id)
        +findById(int id) Book
        +search(string keyword) vector~Book~
        +allBooks() vector~Book~
        +size() size_t
        +saveToFile(string path)
        +loadFromFile(string path) LoadResult
        -find(int id) Book
    }
    class LoadResult {
        +int loaded
        +int skipped
        +vector~string~ warnings
    }
    class TextUtil {
        <<namespace>>
        +trim(string) string
        +toLower(string) string
        +parsePositiveInt(string, int) bool
        +csvEscape(string) string
        +csvSplit(string) vector~string~
    }
    class runtime_error
    class LibraryError
    class InvalidInput
    class BookNotFound
    class DuplicateBook
    class BookUnavailable
    class BookNotIssued
    class FileError

    Library "1" *-- "0..*" Book : books_
    Library ..> LoadResult : returns
    Library ..> TextUtil : uses
    Book ..> TextUtil : uses
    Library ..> LibraryError : throws
    Book ..> LibraryError : throws
    runtime_error <|-- LibraryError
    LibraryError <|-- InvalidInput
    LibraryError <|-- BookNotFound
    LibraryError <|-- DuplicateBook
    LibraryError <|-- BookUnavailable
    LibraryError <|-- BookNotIssued
    LibraryError <|-- FileError
```

## Sample output (excerpt of `./library demo`)
The full output is in [`docs/sample_output.txt`](docs/sample_output.txt).
```
--- 4. Issue and return (normal cases) ---
  > Issue book 101
    [OK] Issued "Clean Code"

--- 5. Error cases (handled with exceptions) ---
  > Issue book 103 again (already issued)
    [Error] Book 103 ("Effective Modern C++") is already issued.
  > Issue book 999 (unknown ID)
    [Error] No book found with ID 999.
  > Add a book with an empty title
    [Error] Invalid input: Title cannot be empty.

--- 7. File error cases ---
  > Load a file that does not exist
    [Error] File error: Cannot open 'no_such_file.csv' for reading.
  > Load demo_bad.csv (contains malformed rows)
    [OK] Loaded 2 good rows, skipped 3 bad rows
    [Warning] Line 3 skipped: invalid book ID 'abc'
```

## Testing
The program was compiled with `-Wall -Wextra -pedantic` (no warnings) and run with AddressSanitizer and
UndefinedBehaviorSanitizer (no errors reported), using both the demo and menu input containing invalid values.

## Author
Shristi Sharma - C++ Programming Practical Manual, Practical 12 (Mini Project)
